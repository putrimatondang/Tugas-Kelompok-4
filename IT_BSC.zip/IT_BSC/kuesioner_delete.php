<?php
    ob_start();
    include ('session.php');
    include('config.php'); 
    mysql_query("DELETE FROM tbkuesioner WHERE id_kuesioner=".$_GET['id'].";") or die(mysql_error());
    
    header ("location:lihatpertanyaan.php");
	
?>