<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "db_tibsc";


$koneksi = mysqli_connect($host, $user, $password, $db) or die("<b>Gagal Terkoneksi: </b>".mysqli_connect_error($koneksi));

?>