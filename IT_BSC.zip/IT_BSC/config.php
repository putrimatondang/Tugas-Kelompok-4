<?php
/*
---------------------------------------------
Developed by IPAN
Theme by: JANUX (Dennis Ji)
---------------------------------------------
*/
mysql_select_db('db_tibsc',  mysql_connect('localhost','root',''))or die(mysql_error());
?>