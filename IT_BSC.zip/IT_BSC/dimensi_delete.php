<?php
    ob_start();
    include ('session.php');
    include('config.php'); 
    mysql_query("DELETE FROM tbdimensi WHERE id_dimensi=".$_GET['id'].";") or die(mysql_error());
    
    header ("location:lihatdimensi.php");
	
?>