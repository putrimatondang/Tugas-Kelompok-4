<?php
    ob_start();
    include ('session.php');
    include('config.php'); 
    mysql_query("DELETE FROM tbpengguna WHERE user_id=".$_GET['id'].";") or die(mysql_error());
    
    header ("location:lihatpengguna.php");
	
?>